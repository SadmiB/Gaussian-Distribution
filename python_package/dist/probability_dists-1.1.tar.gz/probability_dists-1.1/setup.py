from setuptools import setup

setup(name='probability_dists',
      version='1.1',
      description='Probability distributions: Gaussian & Binomial',
      packages=['probability_dists'],
      zip_safe=False)
