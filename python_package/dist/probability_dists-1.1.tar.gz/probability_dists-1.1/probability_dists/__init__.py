from .GaussianDistribution import Gaussian
from .BinomialDistribution import Binomial
# TODO: import the Binomial class from the Binomialdistribution module